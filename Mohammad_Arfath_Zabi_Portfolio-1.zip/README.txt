MOHAMMAD ARFATH ZABI - PORTFOLIO
=================================

Education:
B.Tech Artificial Intelligence & Data Science (AIDS)
REVA University, Bengaluru

How to run:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge.
3. The site is responsive and includes Home, About, Skills, Projects and Contact sections.

For the assignment:
- Take one screenshot at desktop width.
- Take one screenshot at mobile width using browser DevTools/device mode.
- Upload the two screenshots as requested by the assignment.
